package com.example.cameraapp2;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapRegionDecoder;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {

    ImageView pict;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    DatabaseHelper mydb;
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    Button loading;
    static int count2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button cap = (Button) findViewById(R.id.capture);
        loading = (Button) findViewById(R.id.button);
        final EditText data_input = (EditText) findViewById(R.id.editText);

        pict = (ImageView) findViewById(R.id.pic);

        mydb = new DatabaseHelper(this);

        loading.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String newEntry = data_input.getText().toString();
                boolean number = isNumeric(newEntry);
                if(number){
                    retrivepic(newEntry);
                }else{
                    Toast.makeText(MainActivity.this, "please input a proper integer", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public static boolean isNumeric(String str) {
        try {

            return (count2 >=Integer.parseInt(str));
        } catch(NumberFormatException e){
            return false;
        }
    }

    public void insertpic(Bitmap image) {

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 100, stream);


        byte [] byteArray = stream.toByteArray();
        int data_inserted = mydb.insertData(byteArray);

        if (data_inserted >0 ) {
            count2 = data_inserted;
            data_inserted--;
            Toast.makeText(MainActivity.this, "Image ID is: " + data_inserted, Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(MainActivity.this, "Image did NOT save", Toast.LENGTH_SHORT).show();
    }

    /*
    public static byte[] getBitmapAsByteArray(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, outputStream);
        return outputStream.toByteArray();
    }*/



    public void retrivepic(String place) {

        int p = Integer.parseInt(place);
        Cursor c = mydb.getData(p);
        if( c.moveToFirst()) {
            do {

                byte[] bytes = c.getBlob(c.getColumnIndex("IMAGE"));

                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                pict.setImageBitmap(bmp);

            }while(c.moveToNext());
        }
        c.close();

    }


    public void dispatchTakePictureIntent(View view) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            pict.setImageBitmap(imageBitmap);
            insertpic(imageBitmap);
        }
    }
}
