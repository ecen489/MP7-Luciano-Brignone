package com.example.cameraapp2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.lang.annotation.Target;
import java.sql.Blob;
import java.util.Base64;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Camera.db";
    public static final String TABLE_NAME = "IMAGE_TABLE";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "IMAGE";
    int count =1;


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        //SQLiteDatabase db = this.getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME +" (ID INTERGER , IMAGE BLOB);"); //executes the string variable

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }


    public int insertData(byte[] pic_taken){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();


        contentValues.put("IMAGE", pic_taken);
        contentValues.put("ID",count);

        long result = db.insert(TABLE_NAME, null, contentValues); // returns -1 if it fails to insert
        if (result == -1) {
            count++;
            insertData(pic_taken);
            return -1;
        }
        else {
            count++;
            return count;

        }
    }


    public Cursor getData(int place){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cr = db.rawQuery("select * from " + TABLE_NAME +" WHERE ID = "+ place ,null);
        return cr;
    }
    /*
    public byte[] getImage(Cursor c)
    {
        return(c.getBlob(1));
    }*/
}
